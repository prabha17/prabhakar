routerApp.controller('todoPage_ctrl',todoPage_ctrl);

function todoPage_ctrl($scope, $http) {
  //alert('home');
  $http({
      method: 'GET',
      url: 'http://jsonplaceholder.typicode.com/todos?userId=1'
    })
    .success(function(data, status) { 
      $scope.todo_user_data=data;
      console.log('all is good', data);
    })
    .error(function(data, status) {
      console.log('Erreur into url ' + data);
    });
}