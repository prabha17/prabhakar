// app.js
var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
     
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
    .state('home', {
            url: '/home',
            templateUrl: 'home.html',
            controller:'home_ctrl'
        })
        .state('todoPage', {
            url: '/todoPage',
            templateUrl: 'todoPage.html',
            controller:'todoPage_ctrl'
        });
        
});