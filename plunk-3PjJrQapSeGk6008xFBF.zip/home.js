routerApp.controller('home_ctrl',home_ctrl);

function home_ctrl($scope, $http) {
  //alert('home');
  $http({
      method: 'GET',
      url: 'http://jsonplaceholder.typicode.com/users'
    })
    .success(function(data, status) { 
      $scope.home_user_data=data;
      console.log('all is good', data);
    })
    .error(function(data, status) {
      console.log('Erreur into url ' + data);
    });
}